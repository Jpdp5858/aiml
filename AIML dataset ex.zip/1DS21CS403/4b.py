#!/usr/bin/env python
# coding: utf-8

# In[4]:


import numpy as np 
import pandas as pd
import matplotlib.pyplot as plt
df = pd.read_csv(r"C:\Users\202LAB\Desktop\AIML_Lab_Dataset\pgm4\breast_cancer.csv")
df = df.iloc[:, :-1]
df.head()
x = df.iloc[:, 2:].values
y = df.diagnosis.values 
print(x[:2])
print(y[:5])
from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2)
from sklearn.tree import DecisionTreeClassifier 
dt_classifier = DecisionTreeClassifier() 
dt_classifier.fit(x_train, y_train)


# In[6]:


predictions = dt_classifier.predict(x_test)
prob_predictions = dt_classifier.predict_proba(x_test) 
print(predictions)
print(prob_predictions)


# In[10]:


from sklearn.metrics import accuracy_score, confusion_matrix 
print("Training accuracy Score is : ", accuracy_score(y_train, dt_classifier.predict(x_train)))
print("Testing accuracy Score is : ", accuracy_score(y_test, dt_classifier.predict(x_test)))

print("Training Confusion Matrix is : \n", confusion_matrix(y_train, dt_classifier.predict(x_train)))
print("Testing Confusion Matrix is : \n", confusion_matrix(y_test, dt_classifier.predict(x_test)))


# In[20]:


import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import sklearn as sk
df = pd.read_csv("breast_cancer.csv")
df = df.iloc[:,:-1]
df.head()

x = df.iloc[:,2:].values 
y = df.diagnosis.values 
print(x[:2]) 
print(y[:5])

from sklearn.model_selection import train_test_split
x_train, x_test, y_train, y_test = train_test_split(x, y, test_size = 0.2,random_state=500)
x_train.shape
x_test.shape
y_train.shape

y_test.shape
(y_train == 'M').sum()
(y_train=='B').sum()

278/len(y_train)

from sklearn.metrics import accuracy_score, confusion_matrix,classification_report
baseline_pred=["B"] *len(y_train)

accuracy_score(y_train,baseline_pred)
confusion_matrix(y_train,baseline_pred)

from sklearn.naive_bayes import GaussianNB
nb_model=GaussianNB()
nb_model.fit(x_train,y_train)
print(x_train)
nb_model.score(x_train,y_train)
nb_model.score(x_test,y_test)

confusion_matrix(y_train,nb_model.predict(x_train))


# In[21]:


confusion_matrix(y_test,nb_model.predict(x_test))


# In[22]:


print(classification_report(y_train,nb_model.predict(x_train)))


# In[23]:


print(classification_report(y_test,nb_model.predict(x_test)))


# In[ ]:




